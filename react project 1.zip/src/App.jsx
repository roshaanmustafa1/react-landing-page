import { useState } from 'react'
import './App.css'
import Homepage from './components/Homepage'
import TheHeader from './components/TheHeader'

function App() {
  return (
     <>
      <TheHeader />
      <Homepage />
     </>
    
  )
}

export default App
